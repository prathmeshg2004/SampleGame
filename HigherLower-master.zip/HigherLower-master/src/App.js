import './App.css';
import React, { useState, useEffect } from 'react';
import Card from './Components/Card';

function App() {

  return (
    <main className="App">
     <Card />
    </main>
  );
}

export default App;
